using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIOptionGroup : MonoBehaviour
{
    public GameObject OptionPrefab;
    public int OptionNum = 2;


}
